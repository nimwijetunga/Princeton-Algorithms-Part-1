import java.util.Arrays;
import java.util.Collections;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import java.util.ArrayList;

public class FastCollinearPoints {
	
	private LineSegment[] segments;
	private ArrayList<LineSegment> tmp;
	private ArrayList<Point> endP;
	private ArrayList<Double> slopes;
	
	public FastCollinearPoints(Point[] points) {
		tmp = new ArrayList<LineSegment>();
		slopes = new ArrayList<Double>();
		endP = new ArrayList<Point>();
		if(points == null) throw new java.lang.IllegalArgumentException();
		this.checkNull(points);
		duplicates(points);
		Point[] pointsCopy = Arrays.copyOf(points, points.length);
		
		for(int i = 0; i < points.length; i++) {		
			ArrayList<Point> sameSlope = new ArrayList<Point>();
			Arrays.sort(pointsCopy, points[i].slopeOrder());
			
			double curSlope = 0;
			double prevSlope = Double.NEGATIVE_INFINITY;
			
			for(int j = 1; j < pointsCopy.length; j++) {
				curSlope = points[i].slopeTo(pointsCopy[j]);
				if(curSlope == prevSlope) {
					sameSlope.add(pointsCopy[j]);
				}else {
					if(sameSlope.size() >= 3) {
						sameSlope.add(points[i]);
						addSegments(sameSlope, prevSlope);
					}
					sameSlope.clear();
					sameSlope.add(pointsCopy[j]);
				}
				prevSlope = curSlope;
			}
			if(sameSlope.size() >= 3) {
				sameSlope.add(points[i]);
				addSegments(sameSlope, curSlope);
			}
		}
		segments = new LineSegment[tmp.size()];
		int index = 0;
		for(LineSegment value: tmp) {
			segments[index] = value;
			index++;
		}
	}
	
	private void checkNull(Point [] points) {
		 for(int i = 0; i < points.length; i++) {
			 if(points[i] == null)throw new java.lang.IllegalArgumentException();
		 }		
	 }
	
	private void duplicates(Point[] points) {
		for(int i = 0; i < points.length; i++) {
			for(int j = i + 1; j < points.length; j++) {
				if(points[i].compareTo(points[j]) == 0)throw new java.lang.IllegalArgumentException();
			}
		}
	}
	
	private void addSegments(ArrayList<Point> sameSlope, double slope) {
		Collections.sort(sameSlope);
		
		Point start = sameSlope.get(0);
		Point end = sameSlope.get(sameSlope.size() - 1);
		ArrayList<Point> filtEnd = new ArrayList<Point>();
		for(int i = 0; i < slopes.size(); i++) {
			if(slopes.get(i) == slope)filtEnd.add(endP.get(i));
		}
		
		
		
		if(filtEnd.size() == 0) {
			tmp.add(new LineSegment(start,end));
			slopes.add(slope);
			endP.add(end);
		}else {
			for(int i = 0; i < filtEnd.size(); i++) {
				if(end.compareTo(filtEnd.get(i)) == 0) {return;}
			}
			tmp.add(new LineSegment(start,end));
			slopes.add(slope);
			endP.add(end);
		}
	}
	
	public int numberOfSegments() {
		return segments.length;
	}
	
	public LineSegment[] segments() {
		return segments;
	}
	
	public static void main(String[] args) {

	    // read the n points from a file
	    In in = new In("input48.txt");
	    int n = in.readInt();
	    Point[] points = new Point[n];
	    for (int i = 0; i < n; i++) {
	        int x = in.readInt();
	        int y = in.readInt();
	        points[i] = new Point(x, y);
	    }

	    // draw the points
	    StdDraw.enableDoubleBuffering();
	    StdDraw.setXscale(0, 32768);
	    StdDraw.setYscale(0, 32768);
	    for (Point p : points) {
	        p.draw();
	    }
	    StdDraw.show();

	    // print and draw the line segments
	    FastCollinearPoints collinear = new FastCollinearPoints(points);
	    for (LineSegment segment : collinear.segments()) {
	        StdOut.println(segment);
	        segment.draw();
	    }
	    StdDraw.show();
	}
}
